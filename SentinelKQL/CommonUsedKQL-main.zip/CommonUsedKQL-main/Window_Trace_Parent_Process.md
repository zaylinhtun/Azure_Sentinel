## Tracing Parent Process of a Suspected Process

```kusto
SecurityEvent
| where EventID == 4688
| where Computer == "Computer"
| where NewProcessName == "ParentProcessName"
| where NewProcessId == "ProcessId"
```
 > EventID 4688 is process creation event id.

 > Where Computer is the name of the computer that the process you want to investigate run on. 
 
 > Where NewProcessName is the name of the ParentProcessName of the process that you want to investigate.

 > where NewProcessId is the ProcessId of the Parent Process that you want to investigate.