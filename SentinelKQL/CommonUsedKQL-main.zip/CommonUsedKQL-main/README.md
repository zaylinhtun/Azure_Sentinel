# Azure_Sentinel_KQL (Common Use)
### 1) To check the Table Name in Log Analytics <br/>

    union withsource = table * 
    | where TimeGenerated > ago(1d)
    | summarize count() by table
    | sort by table asc
 
 ### 2) To summarize the Event ID with the count function <br/>
    Event
    | where Computer contains "Client"
    | summarize count() by EventID
